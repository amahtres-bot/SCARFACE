SCARFACE Android project

This is an offline Android WebView wrapper for the supplied HTML dashboard.
The dashboard is rebranded as SCARFACE. It does not request INTERNET permission,
so it cannot call remote servers. Metrics are illustrative demo values, not live telemetry.

BUILD THE APK USING ONLY YOUR ANDROID PHONE (GitHub Actions)

1. Open github.com in Chrome and sign in (create a free account if needed).
2. Tap +, choose New repository. Name it scarface-app, set it to Private, and create it.
3. On the repository page choose Add file > Upload files.
4. Extract this ZIP first using your phone's Files app or a ZIP app. Open the
   scarface_android folder and upload ALL its contents, including the hidden
   .github folder. If the phone's file picker hides .github, use the GitHub
   website's Add file > Create new file to create:
   .github/workflows/build-apk.yml
   and paste the workflow contents from the supplied ZIP's same path.
5. Commit the uploaded files to the main branch.
6. Open the Actions tab. Select "Build SCARFACE APK" and tap "Run workflow"
   if it has not started automatically. Wait for the run to finish successfully.
7. Open the completed workflow run, scroll to Artifacts, and download
   SCARFACE-APK. Extract it; the APK inside is app-debug.apk.
8. Tap the APK to install. Android may ask you to allow Chrome/Files to
   install unknown apps; only enable this for the app you used to download it.

If GitHub's mobile layout makes upload difficult, in Chrome use the three-dot
menu > Desktop site. Keep the repository Private. Never upload passwords,
API keys, or personal files.

COMPUTER BUILD (alternative)
Open this folder in Android Studio with JDK 17 and Android SDK Platform 35,
then choose Build > Build Bundle(s) / APK(s) > Build APK(s).
